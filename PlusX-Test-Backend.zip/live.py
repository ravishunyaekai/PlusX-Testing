import os
import time
while 1:
    os.system("cd /root/plusx/backend/ && node server.js")
    time.sleep(2)
